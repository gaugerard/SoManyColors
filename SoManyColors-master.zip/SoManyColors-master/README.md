# SoManyColors
converts PDF for colorblind.
